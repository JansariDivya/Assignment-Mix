/*Problem:- Suppose you have a Piggie Bank with an initial amount of Rs.50 and you have to add some more amount to it. Create a class AddAmount; with a data member named amount with an
initial value of Rs. 50. Now make two constructors of this class*/

#include <iostream>
using namespace std;

class AddAmount
{
    int amount;
public:
    AddAmount()
    {
        amount = 50;
    }

    AddAmount(int a)
    {
        amount = 50;
        amount = a+amount;
    }

    void print_amount()
    {
        cout << amount << endl;
    }
};

int main()
{
    AddAmount a1;
    AddAmount a2(15);
    cout<<"No Paramater"<<endl;
    a1.print_amount();
    cout<<"Having Parameter"<<endl;
    a2.print_amount();
    return 0;
}               