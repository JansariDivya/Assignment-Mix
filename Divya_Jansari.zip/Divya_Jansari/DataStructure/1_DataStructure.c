/*Problem:- In-place merge two sorted arrays.
Given two sorted arrays, X[ ] and Y[ ] of size m and n each, merge elements of X[ ] with elements of array Y[ ] by maintaining the sorted order, i.e., fill X[ ] with the first m smallest elements and fill Y[ ] with remaining elements.*/

#include<stdio.h>
#include<stdlib.h>

void printArray(int arr[], int n)
{
	
	for (int i = 0; i < n; i++) {
		printf("%d ",arr[i]);
	}
	
	printf("\n ");
}


void merge(int X[], int Y[], int m, int n)
{
    int temp;
    
	for (int i = 0; i < m; i++)
	{
	
		if (X[i] > Y[0])
		{
			
			temp = X[i]; 
			X[i] = Y[0];
			Y[0] = temp;
			
			int first = Y[0];

		
			int k;
			for (k = 1; k < n && Y[k] < first; k++) {
				Y[k - 1] = Y[k];
			}

			Y[k - 1] = first;
		}
	}
}

int main()
{
	int X[] = { 1, 4, 7, 8, 10 };
	int Y[] = { 2, 3, 9 };

	int m = sizeof(X) / sizeof(X[0]);
	int n = sizeof(Y) / sizeof(Y[0]);

	merge(X, Y, m, n);
	
	printf(" X[] :\t");
	printArray(X, m);
	printf("Y[] :\t");
	printArray(Y, n);

	return 0;
}