/*Problem:-Write a program to Find whether the given element exists in an array or not. If the element exists in an
array, display YES else No.To print a number following a sequence of elements in an array*/

#include<stdio.h>
int main(){
 int a[10],i,n,m,c=0;
 printf("Enter the size of an array: ");
 scanf("%d",&n);
 printf("Enter the elements of the array: ");
 for(i=0;i<=n-1;i++){
 scanf("%d",&a[i]);
 }
 printf("Enter the number to be search: ");
 scanf("%d",&m);
 for(i=0;i<=n-1;i++){
 if(a[i]==m){
 c=1;
 break;
 }
 }
 if(c==0)
 printf("NO\n");
 else
 printf("YES");
 printf("The number of elements in the array\n");
 for(i=0;i<=n-1;i++)
 printf("%d",a[i]);
 return 0;
}
